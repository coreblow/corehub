// @ts-nocheck
/**
 * Twitch Runtime
 */
import { TwitchExtension } from '../extension.js';
import { TwitchChannelImpl } from './channel.js';

export class TwitchRuntime {
  [k: string]: any;
  private extension: TwitchExtension;
  private channels = new Map<string, TwitchChannelImpl>();
  private running = false;

  constructor(extension: TwitchExtension) {
    this.extension = extension;
  }

  async start() {
    this.running = true;
    return this;
  }

  async stop() {
    this.running = false;
    for (const ch of this.channels.values()) await ch.disconnect();
    this.channels.clear();
  }

  isRunning() { return this.running; }

  getChannel(id: string) {
    if (!this.channels.has(id)) {
      this.channels.set(id, new TwitchChannelImpl(id));
    }
    return this.channels.get(id)!;
  }

  async processMessage(channelId: string, message: any) {
    const channel = this.getChannel(channelId);
    return { channelId, processed: true, extension: this.extension.name };
  }

  async handleWebhook(payload: any) {
    return { handled: true, extension: this.extension.name };
  }
}



// Runtime aliases
let _rt: TwitchRuntime | undefined;
export function getTwitchRuntime(): TwitchRuntime { if (!_rt) _rt = new TwitchRuntime(); return _rt; }
export function setTwitchRuntime(r: TwitchRuntime) { _rt = r; }
