// @ts-nocheck
/**
 * Line Runtime
 */
import { LineExtension } from '../extension.js';
import { LineChannelImpl } from './channel.js';

export class LineRuntime {
  [k: string]: any;
  private extension: LineExtension;
  private channels = new Map<string, LineChannelImpl>();
  private running = false;

  constructor(extension: LineExtension) {
    this.extension = extension;
  }

  async start() {
    this.running = true;
    return this;
  }

  async stop() {
    this.running = false;
    for (const ch of this.channels.values()) await ch.disconnect();
    this.channels.clear();
  }

  isRunning() { return this.running; }

  getChannel(id: string) {
    if (!this.channels.has(id)) {
      this.channels.set(id, new LineChannelImpl(id));
    }
    return this.channels.get(id)!;
  }

  async processMessage(channelId: string, message: any) {
    const channel = this.getChannel(channelId);
    return { channelId, processed: true, extension: this.extension.name };
  }

  async handleWebhook(payload: any) {
    return { handled: true, extension: this.extension.name };
  }
}



// Runtime aliases
let _rt: LineRuntime | undefined;
export function getLineRuntime(): LineRuntime { if (!_rt) _rt = new LineRuntime(); return _rt; }
export function setLineRuntime(r: LineRuntime) { _rt = r; }
export function clearLineRuntime() { _rt = undefined; }
