// @ts-nocheck
/**
 * Line Message Handler
 */
import type { LineMessage } from './types.js';

export class LineHandler {
  async onMessage(message: LineMessage) {
    return { processed: true };
  }

  async onCommand(command: string, args: string[]) {
    return { command, args, handled: true };
  }

  async onReaction(messageId: string, emoji: string) {
    return { messageId, emoji, handled: true };
  }
}
