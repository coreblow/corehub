// @ts-nocheck
/**
 * SynologyChat Runtime
 */
import { SynologyChatExtension } from '../extension.js';
import { SynologyChatChannelImpl } from './channel.js';

export class SynologyChatRuntime {
  [k: string]: any;
  private extension: SynologyChatExtension;
  private channels = new Map<string, SynologyChatChannelImpl>();
  private running = false;

  constructor(extension: SynologyChatExtension) {
    this.extension = extension;
  }

  async start() {
    this.running = true;
    return this;
  }

  async stop() {
    this.running = false;
    for (const ch of this.channels.values()) await ch.disconnect();
    this.channels.clear();
  }

  isRunning() { return this.running; }

  getChannel(id: string) {
    if (!this.channels.has(id)) {
      this.channels.set(id, new SynologyChatChannelImpl(id));
    }
    return this.channels.get(id)!;
  }

  async processMessage(channelId: string, message: any) {
    const channel = this.getChannel(channelId);
    return { channelId, processed: true, extension: this.extension.name };
  }

  async handleWebhook(payload: any) {
    return { handled: true, extension: this.extension.name };
  }
}

// Runtime aliases
let _rt: SynologyChatRuntime | undefined;
export function getSynologyRuntime(): SynologyChatRuntime { if (!_rt) _rt = new SynologyChatRuntime(); return _rt; }
export function setSynologyRuntime(r: SynologyChatRuntime) { _rt = r; }
