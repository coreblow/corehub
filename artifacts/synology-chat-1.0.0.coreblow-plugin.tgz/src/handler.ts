// @ts-nocheck
/**
 * SynologyChat Message Handler
 */
import type { SynologyChatMessage } from './types.js';

export class SynologyChatHandler {
  async onMessage(message: SynologyChatMessage) {
    return { processed: true };
  }

  async onCommand(command: string, args: string[]) {
    return { command, args, handled: true };
  }

  async onReaction(messageId: string, emoji: string) {
    return { messageId, emoji, handled: true };
  }
}
