// @ts-nocheck
import { defineChannelPluginEntry } from "coreblow/plugin-sdk/core";
import { zaloPlugin } from "./src/channel.js";
import { setZaloRuntime } from "./src/runtime.js";

export { zaloPlugin } from "./src/channel.js";
export { setZaloRuntime } from "./src/runtime.js";

export default defineChannelPluginEntry({
  id: "zalo",
  name: "Zalo",
  description: "Zalo channel plugin",
  plugin: zaloPlugin,
  setRuntime: setZaloRuntime,
});
