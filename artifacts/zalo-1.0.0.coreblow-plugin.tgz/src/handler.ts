// @ts-nocheck
/**
 * Zalo Message Handler
 */
import type { ZaloMessage } from './types.js';

export class ZaloHandler {
  async onMessage(message: ZaloMessage) {
    return { processed: true };
  }

  async onCommand(command: string, args: string[]) {
    return { command, args, handled: true };
  }

  async onReaction(messageId: string, emoji: string) {
    return { messageId, emoji, handled: true };
  }
}
