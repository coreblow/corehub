// @ts-nocheck
/**
 * Zalo Runtime
 */
import { ZaloExtension } from '../extension.js';
import { ZaloChannelImpl } from './channel.js';

export class ZaloRuntime {
  [k: string]: any;
  private extension: ZaloExtension;
  private channels = new Map<string, ZaloChannelImpl>();
  private running = false;

  constructor(extension: ZaloExtension) {
    this.extension = extension;
  }

  async start() {
    this.running = true;
    return this;
  }

  async stop() {
    this.running = false;
    for (const ch of this.channels.values()) await ch.disconnect();
    this.channels.clear();
  }

  isRunning() { return this.running; }

  getChannel(id: string) {
    if (!this.channels.has(id)) {
      this.channels.set(id, new ZaloChannelImpl(id));
    }
    return this.channels.get(id)!;
  }

  async processMessage(channelId: string, message: any) {
    const channel = this.getChannel(channelId);
    return { channelId, processed: true, extension: this.extension.name };
  }

  async handleWebhook(payload: any) {
    return { handled: true, extension: this.extension.name };
  }
}

// Runtime aliases
let _rt: ZaloRuntime | undefined;
export function getZaloRuntime(): ZaloRuntime { if (!_rt) _rt = new ZaloRuntime(); return _rt; }
export function setZaloRuntime(r: ZaloRuntime) { _rt = r; }
