import { resolveAckReaction, type CoreBlowConfig } from "../../runtime-api.js";
import type { CoreConfig } from "../../types.js";
import { resolveMatrixAccountConfig } from "../accounts.js";

type MatrixAckReactionScope = "group-mentions" | "group-all" | "direct" | "all" | "none" | "off";

export function resolveMatrixAckReactionConfig(params: {
  cfg: CoreBlowConfig;
  agentId: string;
  accountId?: string | null;
}): { ackReaction: string; ackReactionScope: MatrixAckReactionScope } {
  const matrixConfig = params.cfg.channels?.matrix;
  const accountConfig = resolveMatrixAccountConfig({
    cfg: params.cfg as CoreConfig,
    accountId: params.accountId,
  });
  const ackReaction = resolveAckReaction(params.cfg, params.agentId, {
    channel: "matrix",
    accountId: params.accountId ?? undefined,
  }).trim();
  const ackReactionScope =
    accountConfig.ackReactionScope ??
    matrixConfig?.ackReactionScope ??
    params.cfg.messages?.ackReactionScope ??
    "group-mentions";
  return { ackReaction, ackReactionScope };
}
