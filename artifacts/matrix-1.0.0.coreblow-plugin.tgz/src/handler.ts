// @ts-nocheck
/**
 * Matrix Message Handler
 */
import type { MatrixMessage } from './types.js';

export class MatrixHandler {
  async onMessage(message: MatrixMessage) {
    return { processed: true };
  }

  async onCommand(command: string, args: string[]) {
    return { command, args, handled: true };
  }

  async onReaction(messageId: string, emoji: string) {
    return { messageId, emoji, handled: true };
  }
}
