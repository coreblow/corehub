import type { CoreBlowConfig } from "../runtime-api.js";
import { resolveMattermostAccount } from "./accounts.js";
import {
  createMattermostClient,
  fetchMattermostUser,
  normalizeMattermostBaseUrl,
} from "./client.js";

export type MattermostOpaqueTargetResolution = {
  kind: "user" | "channel";
  id: string;
  to: string;
};

const mattermostOpaqueTargetCache = new Map<string, boolean>();

function cacheKey(baseUrl: string, token: string, id: string): string {
  return `${baseUrl}::${token}::${id}`;
}

/** Mattermost IDs are 26-character lowercase alphanumeric strings. */
export function isMattermostId(value: string): boolean {
  return /^[a-z0-9]{26}$/.test(value);
}

export function isExplicitMattermostTarget(raw: string): boolean {
  const trimmed = raw.trim();
  if (!trimmed) {
    return false;
  }
  return (
    /^(channel|user|mattermost):/i.test(trimmed) ||
    trimmed.startsWith("@") ||
    trimmed.startsWith("#")
  );
}

export function parseMattermostApiStatus(err: unknown): number | undefined {
  if (!err || typeof err !== "object") {
    return undefined;
  }
  const msg = "message" in err ? String((err as { message?: unknown }).message ?? "") : "";
  const match = /Mattermost API (\d{3})\b/.exec(msg);
  if (!match) {
    return undefined;
  }
  const code = Number(match[1]);
  return Number.isFinite(code) ? code : undefined;
}

export async function resolveMattermostOpaqueTarget(params: {
  input: string;
  cfg?: CoreBlowConfig;
  accountId?: string | null;
  token?: string;
  baseUrl?: string;
}): Promise<MattermostOpaqueTargetResolution | null> {
  const input = params.input.trim();
  if (!input || isExplicitMattermostTarget(input) || !isMattermostId(input)) {
    return null;
  }

  const account =
    params.cfg && (!params.token || !params.baseUrl)
      ? resolveMattermostAccount({ cfg: params.cfg, accountId: params.accountId })
      : null;
  const token = params.token?.trim() || account?.botToken?.trim();
  const baseUrl = normalizeMattermostBaseUrl(params.baseUrl ?? account?.baseUrl);
  if (!token || !baseUrl) {
    return null;
  }

  const key = cacheKey(baseUrl, token, input);
  const cached = mattermostOpaqueTargetCache.get(key);
  if (cached === true) {
    return { kind: "user", id: input, to: `user:${input}` };
  }
  if (cached === false) {
    return { kind: "channel", id: input, to: `channel:${input}` };
  }

  const client = createMattermostClient({
    baseUrl,
    botToken: token,
    allowPrivateNetwork: account?.config?.allowPrivateNetwork === true,
  });
  try {
    await fetchMattermostUser(client, input);
    mattermostOpaqueTargetCache.set(key, true);
    return { kind: "user", id: input, to: `user:${input}` };
  } catch (err) {
    if (parseMattermostApiStatus(err) === 404) {
      mattermostOpaqueTargetCache.set(key, false);
    }
    return { kind: "channel", id: input, to: `channel:${input}` };
  }
}

export function resetMattermostOpaqueTargetCacheForTests(): void {
  mattermostOpaqueTargetCache.clear();
}
