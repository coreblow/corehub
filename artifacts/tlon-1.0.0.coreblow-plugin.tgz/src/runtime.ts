// @ts-nocheck
/**
 * Tlon Runtime
 */
import { TlonExtension } from '../extension.js';
import { TlonChannelImpl } from './channel.js';

export class TlonRuntime {
  [k: string]: any;
  private extension: TlonExtension;
  private channels = new Map<string, TlonChannelImpl>();
  private running = false;

  constructor(extension: TlonExtension) {
    this.extension = extension;
  }

  async start() {
    this.running = true;
    return this;
  }

  async stop() {
    this.running = false;
    for (const ch of this.channels.values()) await ch.disconnect();
    this.channels.clear();
  }

  isRunning() { return this.running; }

  getChannel(id: string) {
    if (!this.channels.has(id)) {
      this.channels.set(id, new TlonChannelImpl(id));
    }
    return this.channels.get(id)!;
  }

  async processMessage(channelId: string, message: any) {
    const channel = this.getChannel(channelId);
    return { channelId, processed: true, extension: this.extension.name };
  }

  async handleWebhook(payload: any) {
    return { handled: true, extension: this.extension.name };
  }
}

// Runtime aliases
let _rt: TlonRuntime | undefined;
export function getTlonRuntime(): TlonRuntime { if (!_rt) _rt = new TlonRuntime(); return _rt; }
export function setTlonRuntime(r: TlonRuntime) { _rt = r; }
