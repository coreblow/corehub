import {
  DEFAULT_ACCOUNT_ID,
  listCombinedAccountIds,
  normalizeAccountId,
  resolveMergedAccountConfig,
} from "coreblow/plugin-sdk/account-resolution";
import type { CoreBlowConfig } from "coreblow/plugin-sdk/config-runtime";

type TlonAccountConfig = {
  name?: string;
  enabled?: boolean;
  ship?: string;
  url?: string;
  code?: string;
  allowPrivateNetwork?: boolean;
  groupChannels?: string[];
  dmAllowlist?: string[];
  groupInviteAllowlist?: string[];
  autoDiscoverChannels?: boolean;
  showModelSignature?: boolean;
  autoAcceptDmInvites?: boolean;
  autoAcceptGroupInvites?: boolean;
  defaultAuthorizedShips?: string[];
  ownerShip?: string;
  accounts?: Record<string, TlonAccountConfig>;
};

export type TlonResolvedAccount = {
  accountId: string;
  name: string | null;
  enabled: boolean;
  configured: boolean;
  ship: string | null;
  url: string | null;
  code: string | null;
  allowPrivateNetwork: boolean | null;
  groupChannels: string[];
  dmAllowlist: string[];
  /** Ships allowed to invite us to groups (security: prevent malicious group invites) */
  groupInviteAllowlist: string[];
  autoDiscoverChannels: boolean | null;
  showModelSignature: boolean | null;
  autoAcceptDmInvites: boolean | null;
  autoAcceptGroupInvites: boolean | null;
  defaultAuthorizedShips: string[];
  /** Ship that receives approval requests for DMs, channel mentions, and group invites */
  ownerShip: string | null;
};

function resolveTlonChannelConfig(cfg: CoreBlowConfig): TlonAccountConfig | undefined {
  return cfg.channels?.tlon as TlonAccountConfig | undefined;
}

function resolveMergedTlonAccountConfig(
  cfg: CoreBlowConfig,
  accountId: string,
): Record<string, unknown> & TlonAccountConfig {
  const channel = resolveTlonChannelConfig(cfg);
  if (accountId === DEFAULT_ACCOUNT_ID) {
    return (channel ?? {}) as Record<string, unknown> & TlonAccountConfig;
  }
  return resolveMergedAccountConfig<Record<string, unknown> & TlonAccountConfig>({
    channelConfig: (channel ?? {}) as Record<string, unknown> & TlonAccountConfig,
    accounts: channel?.accounts as
      | Record<string, Partial<Record<string, unknown> & TlonAccountConfig>>
      | undefined,
    accountId,
    normalizeAccountId,
  });
}

export function resolveTlonAccount(
  cfg: CoreBlowConfig,
  accountId?: string | null,
): TlonResolvedAccount {
  const resolvedAccountId = normalizeAccountId(accountId);
  const base = resolveTlonChannelConfig(cfg);

  if (!base) {
    return {
      accountId: resolvedAccountId,
      name: null,
      enabled: false,
      configured: false,
      ship: null,
      url: null,
      code: null,
      allowPrivateNetwork: null,
      groupChannels: [],
      dmAllowlist: [],
      groupInviteAllowlist: [],
      autoDiscoverChannels: null,
      showModelSignature: null,
      autoAcceptDmInvites: null,
      autoAcceptGroupInvites: null,
      defaultAuthorizedShips: [],
      ownerShip: null,
    };
  }

  const merged = resolveMergedTlonAccountConfig(cfg, resolvedAccountId);
  const ship = (merged.ship ?? null) as string | null;
  const url = (merged.url ?? null) as string | null;
  const code = (merged.code ?? null) as string | null;
  const allowPrivateNetwork = (merged.allowPrivateNetwork ?? null) as boolean | null;
  const groupChannels = (merged.groupChannels ?? []) as string[];
  const dmAllowlist = (merged.dmAllowlist ?? []) as string[];
  const groupInviteAllowlist = (merged.groupInviteAllowlist ?? []) as string[];
  const autoDiscoverChannels = (merged.autoDiscoverChannels ?? null) as boolean | null;
  const showModelSignature = (merged.showModelSignature ?? null) as boolean | null;
  const autoAcceptDmInvites = (merged.autoAcceptDmInvites ?? null) as boolean | null;
  const autoAcceptGroupInvites = (merged.autoAcceptGroupInvites ?? null) as boolean | null;
  const ownerShip = (merged.ownerShip ?? null) as string | null;
  const defaultAuthorizedShips = (merged.defaultAuthorizedShips ?? []) as string[];
  const configured = Boolean(ship && url && code);

  return {
    accountId: resolvedAccountId,
    name: (merged.name ?? null) as string | null,
    enabled: merged.enabled !== false,
    configured,
    ship,
    url,
    code,
    allowPrivateNetwork,
    groupChannels,
    dmAllowlist,
    groupInviteAllowlist,
    autoDiscoverChannels,
    showModelSignature,
    autoAcceptDmInvites,
    autoAcceptGroupInvites,
    defaultAuthorizedShips,
    ownerShip,
  };
}

export function listTlonAccountIds(cfg: CoreBlowConfig): string[] {
  const base = resolveTlonChannelConfig(cfg);
  if (!base) {
    return [];
  }
  return listCombinedAccountIds({
    configuredAccountIds: Object.keys(base.accounts ?? {}).map(normalizeAccountId),
    implicitAccountId: base.ship ? DEFAULT_ACCOUNT_ID : undefined,
  });
}
