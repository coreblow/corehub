import {
  createAccountActionGate,
  createAccountListHelpers,
  resolveMergedAccountConfig,
} from "coreblow/plugin-sdk/account-helpers";
import { normalizeAccountId } from "coreblow/plugin-sdk/account-id";
import { resolveAccountEntry } from "coreblow/plugin-sdk/routing";
import type { DiscordAccountConfig, DiscordActionConfig, CoreBlowConfig } from "./runtime-api.js";
import { resolveDiscordToken } from "./token.js";

export type ResolvedDiscordAccount = {
  accountId: string;
  enabled: boolean;
  name?: string;
  token: string;
  tokenSource: "env" | "config" | "none";
  config: DiscordAccountConfig;
};

const { listAccountIds, resolveDefaultAccountId } = createAccountListHelpers("discord");
export const listDiscordAccountIds = listAccountIds;
export const resolveDefaultDiscordAccountId = resolveDefaultAccountId;

export function resolveDiscordAccountConfig(
  cfg: CoreBlowConfig,
  accountId: string,
): DiscordAccountConfig | undefined {
  return resolveAccountEntry(cfg.channels?.discord?.accounts, accountId);
}

export function mergeDiscordAccountConfig(
  cfg: CoreBlowConfig,
  accountId: string,
): DiscordAccountConfig {
  return resolveMergedAccountConfig<DiscordAccountConfig>({
    channelConfig: cfg.channels?.discord as DiscordAccountConfig | undefined,
    accounts: cfg.channels?.discord?.accounts as
      | Record<string, Partial<DiscordAccountConfig>>
      | undefined,
    accountId,
  });
}

export function createDiscordActionGate(params: {
  cfg: CoreBlowConfig;
  accountId?: string | null;
}): (key: keyof DiscordActionConfig, defaultValue?: boolean) => boolean {
  const accountId = normalizeAccountId(params.accountId);
  return createAccountActionGate({
    baseActions: params.cfg.channels?.discord?.actions,
    accountActions: resolveDiscordAccountConfig(params.cfg, accountId)?.actions,
  });
}

export function resolveDiscordAccount(params: {
  cfg: CoreBlowConfig;
  accountId?: string | null;
}): ResolvedDiscordAccount {
  const accountId = normalizeAccountId(params.accountId);
  const baseEnabled = params.cfg.channels?.discord?.enabled !== false;
  const merged = mergeDiscordAccountConfig(params.cfg, accountId);
  const accountEnabled = merged.enabled !== false;
  const enabled = baseEnabled && accountEnabled;
  const tokenResolution = resolveDiscordToken(params.cfg, { accountId });
  return {
    accountId,
    enabled,
    name: merged.name?.trim() || undefined,
    token: tokenResolution.token,
    tokenSource: tokenResolution.source,
    config: merged,
  };
}

export function resolveDiscordMaxLinesPerMessage(params: {
  cfg: CoreBlowConfig;
  discordConfig?: DiscordAccountConfig | null;
  accountId?: string | null;
}): number | undefined {
  if (typeof params.discordConfig?.maxLinesPerMessage === "number") {
    return params.discordConfig.maxLinesPerMessage;
  }
  return resolveDiscordAccount({
    cfg: params.cfg,
    accountId: params.accountId,
  }).config.maxLinesPerMessage;
}

export function listEnabledDiscordAccounts(cfg: CoreBlowConfig): ResolvedDiscordAccount[] {
  return listDiscordAccountIds(cfg)
    .map((accountId) => resolveDiscordAccount({ cfg, accountId }))
    .filter((account) => account.enabled);
}

export function resolveDiscordAccountAllowFrom(params: {
  cfg: CoreBlowConfig;
  accountId?: string | null;
}): string[] | undefined {
  const account = resolveDiscordAccount(params);
  return account.config.allowFrom ?? account.config.dm?.allowFrom;
}

export type ChannelDmPolicy = "open" | "pairing" | "allowlist" | "disabled";

export function resolveDiscordAccountDmPolicy(params: {
  cfg: CoreBlowConfig;
  accountId?: string | null;
}): ChannelDmPolicy | undefined {
  const account = resolveDiscordAccount(params);
  const policy = account.config.dm?.policy;
  if (policy === "pairing" || policy === "allowlist" || policy === "open" || policy === "disabled") {
    return policy;
  }
  const rootPolicy = params.cfg.channels?.discord?.dm?.policy;
  if (rootPolicy === "pairing" || rootPolicy === "allowlist" || rootPolicy === "open" || rootPolicy === "disabled") {
    return rootPolicy;
  }
  return "pairing";
}
