export { createThreadBindingManager } from "./src/monitor/thread-bindings.manager.js";
export { __testing as discordThreadBindingTesting } from "./src/monitor/thread-bindings.manager.js";
export {
  listDiscordDirectoryGroupsFromConfig,
  listDiscordDirectoryPeersFromConfig,
} from "./src/directory-config.js";
export {
  collectRuntimeConfigAssignments,
  secretTargetRegistryEntries,
} from "./src/secret-config-contract.js";
export {
  unsupportedSecretRefSurfacePatterns,
  collectUnsupportedSecretRefConfigCandidates,
} from "./src/security-contract.js";
export { deriveLegacySessionChatType } from "./src/session-contract.js";
export type {
  DiscordInteractiveHandlerContext,
} from "./src/interactive-dispatch.js";
export { collectDiscordSecurityAuditFindings } from "./src/security-audit.js";
