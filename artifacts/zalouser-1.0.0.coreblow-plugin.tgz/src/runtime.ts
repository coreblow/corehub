// @ts-nocheck
/**
 * Zalouser Runtime
 */
import { ZalouserExtension } from '../extension.js';
import { ZalouserChannelImpl } from './channel.js';

export class ZalouserRuntime {
  [k: string]: any;
  private extension: ZalouserExtension;
  private channels = new Map<string, ZalouserChannelImpl>();
  private running = false;

  constructor(extension: ZalouserExtension) {
    this.extension = extension;
  }

  async start() {
    this.running = true;
    return this;
  }

  async stop() {
    this.running = false;
    for (const ch of this.channels.values()) await ch.disconnect();
    this.channels.clear();
  }

  isRunning() { return this.running; }

  getChannel(id: string) {
    if (!this.channels.has(id)) {
      this.channels.set(id, new ZalouserChannelImpl(id));
    }
    return this.channels.get(id)!;
  }

  async processMessage(channelId: string, message: any) {
    const channel = this.getChannel(channelId);
    return { channelId, processed: true, extension: this.extension.name };
  }

  async handleWebhook(payload: any) {
    return { handled: true, extension: this.extension.name };
  }
}

let _rt: ZalouserRuntime | undefined;
export function getZalouserRuntime(): ZalouserRuntime { if (!_rt) throw new Error("Zalouser runtime not initialized"); return _rt; }
export function setZalouserRuntime(runtime: any): void { _rt = runtime; }
export function clearZalouserRuntime(): void { _rt = undefined; }
